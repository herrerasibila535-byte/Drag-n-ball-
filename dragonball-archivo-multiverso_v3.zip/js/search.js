
const searchInput=document.getElementById("searchInput");

searchInput.addEventListener("input",()=>{
 const q=searchInput.value.toLowerCase();
 document.querySelectorAll(".node").forEach(n=>{
  const match=n.textContent.toLowerCase().includes(q);
  n.classList.toggle("match",match);
  n.parentElement.style.display=match||!q?"block":"none";
 });
});
