
const container=document.getElementById("sagas");

const VIDEOS={
 "Dragon Ball Z":"media/video/dbz.mp4",
 "Dragon Ball Super":"media/video/super.mp4",
 "Dragon Ball GT":"media/video/gt.mp4"
};

const observer=new IntersectionObserver(entries=>{
 entries.forEach(e=>{
  if(e.isIntersecting){
   e.target.play();
  }else{
   e.target.pause();
  }
 });
},{threshold:.6});

SAGAS.forEach(s=>{
 const v=document.createElement("video");
 v.src=VIDEOS[s.name];
 v.muted=true;
 v.loop=true;
 v.playsInline=true;
 v.className="saga-video";
 v.addEventListener("click",()=>speakSaga(s.name));
 container.appendChild(v);
 observer.observe(v);
});
