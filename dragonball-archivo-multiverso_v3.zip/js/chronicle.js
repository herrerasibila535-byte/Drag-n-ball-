
const chronicle=document.getElementById("chronicle");
function speakSaga(name){
chronicle.textContent=
name==="Dragon Ball Z"
?"El guerrero dorado alzó su furia. La muerte aprendió a temer."
:name==="Dragon Ball Super"
?"Los dioses observan. El mortal desafía el límite."
:"El eco final del héroe resuena en un tiempo olvidado.";
}
