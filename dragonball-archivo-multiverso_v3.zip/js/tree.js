
const TREE_DATA = {
 DBZ:["Saiyan","Freezer","Cell","Majin Buu"],
 SUPER:["Bills","Tournament of Power","Ultra Instinct"],
 GT:["Baby","Super 17","Dragons Oscuros"]
};

const treeContainer=document.getElementById("tree");

function buildTree(){
 const ul=document.createElement("ul");
 Object.entries(TREE_DATA).forEach(([universe,sagas])=>{
  const li=document.createElement("li");
  const btn=document.createElement("button");
  btn.textContent=universe;
  btn.className="node";
  const branch=document.createElement("ul");
  branch.className="branch";
  sagas.forEach(s=>{
    const c=document.createElement("li");
    c.textContent=s;
    branch.appendChild(c);
  });
  btn.onclick=()=>branch.classList.toggle("open");
  li.appendChild(btn);
  li.appendChild(branch);
  ul.appendChild(li);
 });
 treeContainer.appendChild(ul);
}
buildTree();
