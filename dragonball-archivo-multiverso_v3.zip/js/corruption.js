
document.addEventListener("dblclick",()=>{
document.body.classList.add("corrupt");
setTimeout(()=>document.body.classList.remove("corrupt"),2500);
});
