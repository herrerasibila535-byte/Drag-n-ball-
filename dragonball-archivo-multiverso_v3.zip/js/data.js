
const SAGAS=[
{name:"Dragon Ball Z",video:""},
{name:"Dragon Ball Super",video:""},
{name:"Dragon Ball GT",video:""}
];
