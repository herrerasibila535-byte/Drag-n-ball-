
console.log("Archivo del Multiverso activo");
